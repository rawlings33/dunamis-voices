document.getElementById("searchBtn").addEventListener("click", function() {
  document.getElementById("searchOverlay").style.display = "flex";
});
document.getElementById("closeSearch").addEventListener("click", function() {
  document.getElementById("searchOverlay").style.display = "none";
});

// Subscription toggle (placeholder)
function toggleBilling() {
  const toggle = document.getElementById("billingToggle");
  const monthly = document.getElementById("monthlyPlan");
  const yearly = document.getElementById("yearlyPlan");
  if (toggle.checked) {
    monthly.style.display = "none";
    yearly.style.display = "block";
  } else {
    monthly.style.display = "block";
    yearly.style.display = "none";
  }
}

// Player play button
const playBtn = document.getElementById("playBtn");
if (playBtn) {
  const audio = new Audio("assets/audio/sample.mp3");
  playBtn.addEventListener("click", () => {
    if (audio.paused) {
      audio.play();
      playBtn.textContent = "⏸";
    } else {
      audio.pause();
      playBtn.textContent = "▶";
    }
  });
}
